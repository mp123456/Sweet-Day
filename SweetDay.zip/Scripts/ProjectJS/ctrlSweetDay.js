﻿/// <reference path="P:\LearningTools\DEV\navah3\SweetDay\Views/Home/_Feelings.cshtml" />
myModule.controller('sweetDayController', function ($scope, $rootScope, $timeout, $filter, SweetDay) {
    
    $scope.msg = "";
    $scope.allowThrowCube = true;
    $scope.currentSqure = {};
    $scope.showFood = false;
    $scope.showFeelings = false;
    $scope.showInsulin = false;
    $scope.showPantry = false;
    $scope.showPantryInsulin = true;
    $scope.firstProperty = "my property";
    $scope.template = '/Login/LoginMain'
    $scope.multiPhone = 0;
    $scope.userFound = 0;
    $scope.users;
    $scope.Players = [{ name: "player1", src: "/Images/login/Boy1.png" },
                      { name: "player2", src: "/Images/login/Boy2.png" },
                      { name: "player3", src: "/Images/login/Boy3.png" },
                      { name: "player4", src: "/Images/login/Girl1.png" },
                      { name: "player5", src: "/Images/login/Girl2.png" },
                      { name: "player6", src: "/Images/login/Girl3.png" }]
    $scope.User = {
        phone: "", firstName: "", lastName: "", dateOfBirth: "", insulin: "", carbohydrate: "", email: "", sex: "", player: "", userSelect: "", glucose: 100
        , increaseGlucose: "", decreaseGlucose: "", indexUser: 0, doctorVisitNum: "", junkFoodNum: "", dot: 0, id: 0,insulinEmpty: "",insulinFull: ""
    }

    $scope.NewLogin = function () {
        $scope.template = '/Login/NewLogin'
    }
    $scope.existsLogin = function () {
        $scope.template = '/Login/LoginPhons'
    }

    $scope.IsExisting = function () {
        SweetDay.IsExisting($scope.User.phone)
        .then(function mySuccess(response) {
            if (response.data.length > 0) {
                if (response.data.length == 1) {
                    $scope.User.id = response.data[0].ID;
                    $scope.User.indexUser = response.data[0].IndexUser!=null?response.data[0].IndexUser:0;
                    $scope.User.firstName = response.data[0].FirstName;
                    $scope.User.lastName = response.data[0].LastName;
                    $scope.User.insulin = response.data[0].Insulin;
                    $scope.User.carbohydrate = response.data[0].Carbohydrate;
                    //$scope.User.player = response.data[0].Player;
                    $scope.User.glucose = response.data[0].Glucose;
                    $scope.User.increaseGlucose = response.data[0].IncreaseGlucose;
                    $scope.User.decreaseGlucose = response.data[0].DecreaseGlucose;
                    $scope.User.doctorVisitNum = response.data[0].DoctorVisitNum;
                    $scope.User.junkFoodNum = response.data[0].JunkFoodNum;
                    $scope.User.insulinFull = response.data[0].InsulinFull;
                    $scope.User.insulinEmpty = response.data[0].InsulinEmpty;
                    $scope.User.dot = response.data[0].Dot;
                    if (response.data[0].IndexUser > 0) {
                        $scope.userFound = 1;
                    }
                    else {
                        $scope.template = '/Home/Index';
                    }
                    $scope.aaa = 'סמן את מספר המנות בהן תרצה להשתמש - שים לב! נותרו לך: ' + $scope.User.insulinFull;
                }
                else {
                    $scope.userFound = 2;
                    $scope.multiPhone = 1;
                    $scope.users = response.data;
                }
            }
            else {
                var a = $scope.User.player;
                var b = $scope.User.phone;
                $scope.template = '/Login/NewLogin'
                //$location.path("http://" + window.location.host + "/Login/NewLogin");
                //$location.absUrl = $location.path();
                //$scope.$apply();
                //window.location = "http://" + window.location.host + "/Login/NewLogin"
            }
        }, function myError(response) {
            return response.statusText;
        });
    }

    $scope.getTemplate = function () {
        return $scope.template
    }
    $scope.selectedPlayer = function (player) {
        var x = player;
        $scope.User.player = x;
    }
    $scope.selectedUser = function () {
        $scope.User.id = $scope.User.userSelect.ID;
        $scope.User.firstName = $scope.User.userSelect.FirstName;
        $scope.User.lastName = $scope.User.userSelect.LastName;
        $scope.User.insulin = $scope.User.userSelect.Insulin;
        $scope.User.carbohydrate = $scope.User.userSelect.Carbohydrate;
        $scope.User.player = $scope.User.userSelect.Player;
        $scope.User.glucose = $scope.User.userSelect.Glucose;
        $scope.User.increaseGlucose = $scope.User.userSelect.IncreaseGlucose;
        $scope.User.decreaseGlucose = $scope.User.userSelect.DecreaseGlucose;
        $scope.User.doctorVisitNum = $scope.User.userSelect.DoctorVisitNum;
        $scope.User.junkFoodNum = $scope.User.userSelect.JunkFoodNum;
        $scope.User.insulinFull = $scope.User.userSelect.InsulinFull;
        $scope.User.insulinEmpty = $scope.User.userSelect.InsulinEmpty;
        $scope.User.dot = $scope.User.userSelect.Dot;
        $scope.User.indexUser = $scope.User.userSelect.indexUser;
        if ($scope.User.userSelect.IndexUser > 0) {
            $scope.userFound = 1;
        }
        else {
            $scope.template = '/Home/Index';
        }
        $scope.aaa = 'סמן את מספר המנות בהן תרצה להשתמש - שים לב! נותרו לך: ' + $scope.User.insulinFull;
    }
    $scope.SaveLogin = function () {
        SweetDay.SaveLogin($scope.User)
        .then(function mySuccess(response) {
            if (response.data.isExist == true) {
                alert('הנך רשום במערכת');
                $scope.template = '/Login/LoginPhons';
            }
            else {
                $scope.User.insulinFull = 8;
                $scope.User.insulinEmpty = 0;
                $scope.User.id = response.data.user.ID;
                $scope.User.dot = 0;
                $scope.User.glucose = 100;
                $scope.template = '/Home/Index';
                $scope.aaa = 'סמן את מספר המנות בהן תרצה להשתמש - שים לב! נותרו לך: ' + $scope.User.insulinFull;
            }
        }, function myError(response) {
            return response.statusText;
        });
    }
    $scope.NewGame = function () {
        $scope.showPantryInsulin = true;
        $scope.allowThrowCube = true;
        $scope.User.glucose = 100;
        $scope.User.indexUser = 0;
        //$scope.User.insulin = 0;
        $scope.User.increaseGlucose = 0;
        $scope.User.decreaseGlucose = 0;
        $scope.User.doctorVisitNum = 0;
        $scope.User.junkFoodNum = 0;
        $scope.User.insulinFull = 8;
        $scope.User.insulinEmpty = 0;
        $scope.User.dot = 0;
        $scope.template = '/Home/Index'
        $scope.aaa = 'סמן את מספר המנות בהן תרצה להשתמש - שים לב! נותרו לך: ' + $scope.User.insulinFull;

    }
    $scope.PrevGame = function () {
        $scope.template = '/Home/Index'
    }
    
    //-----------------------------------------//
    //modalsFanctions//
    $scope.showModalSugar = false;
    $scope.showModal2 = false;
    $scope.showModalDoc = false;
    $scope.showModalTask = false;

    // $scope.User.glucose = 500;
    /// show modal doctor
    $scope.showDoctor = function () {
        if ($scope.User.glucose >= 500) {
            $scope.showModalSugar = false;
            $scope.showPantry = false;
            $scope.showPantryInsulin = false;
            $scope.showModalDoc = true;
            return true;
        }
        return false;
    }


    $scope.hide = function (value) {

        if (value == 1) {
            $scope.showModal2 = false;
        }
        if (value == 2) {
            //$scope.showModalDoc = false;
            $scope.User.insulinFull = 8;
            $scope.User.glucose = 100; //sugar
        }

        if (value == 3) {
            $scope.showModalTask = false;
            $scope.msg = "";
            $scope.allowThrowCube = true;
            $scope.allowTaskSelect = false;
            $scope.task = [];
        }
        if (value == 4) {
            $scope.showSurprise = false;
            $scope.surprise = [];
        }
        if (value == 5) {
            $scope.showFeelings = false;
        }
        if (value == 6) {
            $scope.showInsulin = false;
        }
        if (value == 7) {
            $scope.showFood = false;
            $scope.showInsulin = true;
            return;
        }

        if (value == 8) {
            $scope.showFood = false;
        }
        if (value == 9) {
            $scope.showInsulin = false;
        }
        if (value == 10) {
            $scope.showFeelings = false;
        }
        if (value == 11) {
            $scope.showFood = false;
        }

        if (value == 12) {
            $scope.showPantry = false;
        }
        if (value == 13) {
            $scope.showInsulin = true;
            $scope.showModalSugar = false;
            return;
        }
        if (value == 14) {
            $scope.showPantry = true;
            $scope.showModalSugar = false;
            return;
        }

        $scope.allowThrowCube = true;
        $scope.showPantryInsulin = true;

    }

    $scope.GoInsulin = function () {
        $scope.showInsulin = true;
        $scope.showPantryInsulin = false;
    }

    $scope.GoFood = function () {
        $scope.showPantry = true;
        $scope.showPantryInsulin = false;
    }

    $scope.ShowHelp = function () {
        $scope.showModal2 = false;
        $scope.showModal2 = true;
    }

    //ליבדוק על איזו משבצת דרך ואז לקרוא לפונקציה TASK()
    $scope.task = { taskTitle: "", answers: "" }
    $scope.Task = function () {
        SweetDay.Task()
            .then(function mySuccess(response) {
                //SweetDay.NotExisting()
                if (response.statusText == "OK") {
                    $scope.task.taskTitle = response.data.TaskTitle;
                    $scope.task.answers = response.data.Answers;
                }
                else {

                }
            }, function myError(response) {
                return response.statusText;
            });;
    }

    var count = 0;
    // check the answer of task
    $scope.checkanswer = function (choice, anstitle) {
        $scope.allowTaskSelect = true;
        if (choice == true) {
            $scope.User.dot = $scope.User.dot + 10;
            $scope.msg = 'מצוין, צדקת!, כל הכבוד:)';
        }
        else {
            for (let i of  $scope.task.answers)
            {
                count++;
                if (i.IsCorrect == true) {
                    var ans = i.Answertitle;
                    break;
                }
            }
            $scope.User.dot = $scope.User.dot - 5
            $scope.msg = 'חבל טעית, התשובה היא: ' + count;
        }
        a = 0;
        count = 0;
    };

    // ---------------------------------------//
    //שומר את ערכי המשבצת
    //$scope.answer1 = '';
    //$scope.keepSquere = function (squere) {
    //    $scope.squere = squere
    //}
    ////בודק האם בחר רמה נכונה לפי התחושה 
    //$scope.checking = function (feelingId) {
    //    $scope.feeling = feelingId
    //    if ($scope.squere.Carbohydrates == feelingId) {
    //        $scope.answer1 = 'נכון';
    //    }
    //    else {
    //        $scope.answer1 = 'לא נכון';
    //    }
    //}
    //////////////////////////////////////////////////////

    $scope.Food = function () {
        $scope.Food1 = true;
    }

    $scope.YesFood = function () {
        $scope.showFood = false;
        $scope.Insulin = true;

    }
    $scope.NoFood = function () {
        $scope.showFood = false;
    }

    /////////////////////////////////

    //$scope.SavingTheGame = function () {
    //    var x = $scope.User.id
    //    var y = $scope.insulinsolider
    //    //  
    //    // user id, index(משבצת)
    //    //    גלוקוז, קלפים להורדת סוכר-decreas
    //    //    לעליית סוכר 
    //    //    תמונה של חייל 
    //    //    לשלוח לסרבר, 
    //    //    כפתור "שמור משחק" 


    //    //בודק אם לחץ על כפתור קבל עזרה  
    //    //if ($scope.click) {
    //    // consol.log("האינסולין ירד ל100")
    //    //אם כן משנה את האינסולין ל100 
    //    //$scope.insulin = 100;
    //    //וסוגר את המודל
    //    // $scope.showModal1 = false;
    //    // }

    //}

    //-------------------------------------------------
    //משתני מזרקי אינסולין
    $scope.bigInsulin = false;
    $scope.InsulinSelected = 0; //מזרק אינסולין עם בחירה
    $scope.Amount = 0; //כמות האינסולין הרצויה
    $scope.a = 0;
    $scope.exact = false;
    //$scope.showcloseInsulin = false;
    $scope.aaa = 'סמן את מספר המנות בהן תרצה להשתמש - שים לב! נותרו לך: ' + $scope.User.insulinFull;

    //פונ' לקבלת מספר המקומות במערך המזרקים
    $scope.getTimes = function (n) {
        return new Array(n);
    };

    //לחיצה על מזרק מלא
    $scope.RatioInsulin = function (id) {
        if (angular.element('#insulin_' + id).hasClass('insulinSelect')) {
            angular.element('#insulin_' + id).removeClass('insulinSelect');
            $scope.InsulinSelected--;
        }
        else {
            angular.element('#insulin_' + id).addClass("insulinSelect");
            $scope.InsulinSelected++;
        }
    }
    //לחיצה על המזרק הגדול
    $scope.Syringe = function () {
        if ($scope.bigInsulin == false) {
           
            $scope.bigInsulin = true;
            //במקרה של מאכל חישוב יחס פחמימות
            if ($scope.currentSqure.SquareType == 1) {
                $scope.Amount = Math.round($scope.currentSqure.Carbohydrates / $scope.User.carbohydrate);
            }
             //במקרה של רמת סוכר חדשה גבוהה חישוב יחס אינסולין
            else if ($scope.currentSqure.SquareType == 2) {
                $scope.Amount = Math.round(($scope.User.glucose - 100) / $scope.User.insulin);
            }
                if ($scope.Amount == $scope.InsulinSelected) {
                    $scope.User.insulinFull -= $scope.Amount;
                    $scope.User.insulinEmpty += $scope.Amount;
                    $scope.User.dot += 10;
                    $scope.exact = true;
                    //$scope.showcloseInsulin = true;
                    $scope.aaa = 'יפה מאד! צדקת. נותרו לך - ' + $scope.User.insulinFull + ' מזרקים';
                }
                else if($scope.Amount > $scope.InsulinSelected && $scope.Amount > $scope.User.insulinFull){
                    $scope.User.insulinEmpty += $scope.User.insulinFull;
                    $scope.User.insulinFull = 0;
                    $scope.User.dot += 10;
                    $scope.aaa = 'אין ברשותך מספיק מזרקים, רמת הסוכר שלך עלתה';
                    $scope.exact = true;

                }
                else {
                    $scope.exact = false;
                    $scope.User.insulinFull -= $scope.Amount;
                    $scope.User.insulinEmpty += $scope.Amount;
                    $scope.User.dot -= 5;
                    $scope.aaa = 'הכמות הרצויה היא: ' + $scope.Amount + " נותרו לך - " + $scope.User.insulinFull + " מזרקים";
                }
                $timeout(closeInsulin, 5000);
        };
        //if ($scope.InsulinSelected > $scope.Amount) {
        //    $scope.aaa = 'בחרת כמות גדולה מידי';
        //}
        //else {
        //    $scope.aaa = 'בחרת כמות קטנה מידי';
        //}
    };
   
    function closeInsulin() {
        for (var i = 0; i < $scope.User.insulinFull; i++) {
            if (angular.element('#insulin_' + i).hasClass('insulinSelect')) {
                //angular.element('#insulin_' + i).addClass('insulinToEmpty');
                angular.element('#insulin_' + i).removeClass('insulinSelect');
                //angular.element('#insulin_' + i).addClass('insulinEmp');
            }
        }
        $scope.hide(9);
       
        if ($scope.currentSqure.SquareType == 1 && $scope.exact==true) {
            $scope.User.glucose += Math.round(($scope.currentSqure.Carbohydrates - ($scope.InsulinSelected * $scope.User.carbohydrate)) * ($scope.User.carbohydrate / $scope.User.insulin))
        }
        else if ($scope.currentSqure.SquareType == 1 && $scope.exact == false) {
            $scope.User.glucose += Math.round(($scope.currentSqure.Carbohydrates - ($scope.Amount * $scope.User.carbohydrate)) * ($scope.User.carbohydrate / $scope.User.insulin))
        }
        else if ($scope.currentSqure.SquareType == 2 && $scope.exact == true) {
                $scope.User.glucose -= $scope.User.insulin * $scope.InsulinSelected;
        }
        else if ($scope.currentSqure.SquareType == 2 && $scope.exact == false) {
            $scope.User.glucose -= $scope.User.insulin * $scope.Amount;
        }

        $scope.InsulinSelected = 0;
        $scope.Amount = 0;
        $scope.exact = false;
        $scope.aaa = 'סמן את מספר המנות בהן תרצה להשתמש - שים לב! נותרו לך: ' + $scope.User.insulinFull;
        $scope.bigInsulin = false;
        //$scope.showcloseInsulin = false;
        //$scope.showInsulin = false;
    };


    //-------------------------------------------------
    //ארון אוכל


    $scope.Foods1 = [
        {
            foodName: '2 בסקוויט', src: 'Biscuit', carbohydrates: '11'
        },
    {
        foodName: 'כוס פופקורן', src: 'Popcorn', carbohydrates: '6'
    },
    {
        foodName: 'מלון', src: 'Melon', carbohydrates: '12'
    },
    {
        foodName: 'כוס קולה', src: 'Coca_Cola', carbohydrates: '25'
    }];

    $scope.Foods2 = [
    {
        foodName: 'קורנפלקס', src: 'Cereal', carbohydrates: '25'
    },
    {
        foodName: 'פרוסת לחם', src: 'Bread', carbohydrates: '11'
    },
    {
        foodName: '2 סוכריות', src: 'Candies', carbohydrates: '11'
    },
    {
        foodName: '5 קרקרים', src: 'Cracker', carbohydrates: '16'
    }];
    $scope.Foods3 = [
    {
        foodName: 'כוס אורז', src: 'Rice', carbohydrates: '41'
    },
    {
        foodName: 'כוס מיץ תפוזים', src: 'Juice', carbohydrates: '33'
    },
    {
        foodName: 'בייגלה', src: 'Beagle', carbohydrates: '35'
    },
    {
        foodName: 'כוס חלב', src: 'Milk', carbohydrates: '10'
    }];


    //בחירת מאכל מהארון והעלאת רמת הסוכר לפי מספר הפחמימות
    $scope.selectFood = function (food) {

        //fCarbohydrates = $scope.Foods[id].carbohydrates;

        //אופן החישוב - פחמימות_המאכל*יחס_פחמימות/יחס_אינסולין
        $scope.User.glucose += Math.round(food.carbohydrates * $scope.User.carbohydrate / $scope.User.insulin);
        $timeout($scope.hide(12), 3000);
 

    }

    //------------------------------------------------
    //כפתור שינוי יחס פחמימה

    $scope.SaveChangeRatio = function () {
        SweetDay.SaveChangeRatio($scope.User.id, $scope.User.insulin, $scope.User.carbohydrate)
    }
    $scope.showChangeRatio = false;




    //--------------------------
    //תחושות
    $scope.showcloseFeeling = false;
    $scope.ansFeeling = '';
    //התחושה של המשבצת הנוכחית
    $scope.checkFeeling = function (hip) {
        if ($scope.showcloseFeeling == false) {
            if (hip == $scope.currentSqure.Carbohydrates) {
                $scope.ansFeeling = 'נכון מאד!';
                $scope.User.dot += 10;

            }
            else {
                $scope.ansFeeling = 'התשובה לא נכונה';
                $scope.User.dot -= 5;
            }
            $scope.showcloseFeeling = true;
        }
    }
    //סגירת ממסך תחושות

    $scope.closeFeeling = function () {
        $scope.showcloseFeeling = false;
        $scope.ansFeeling = '';
        $scope.hide(10);


    }
    //------------
    $scope.images = [null, '/1T.png', '/2T.png', '/3T.png', '/4T.png', '/5T.png', '/6T.png'];

    //$scope.currentIndex = 1;
    $scope.thisImage = $scope.images[3];
    $scope.showstage = false;
    $scope.showImage = true;
    function getRandomSpan() {
        if ($scope.User.indexUser < 37)
            return Math.floor((Math.random() * 6) + 1);
        else
            return Math.floor((Math.random() * (43 - $scope.User.indexUser)) + 1);
    };
    //cubeFunctions

    $scope.ThrowCube = function () {
        if ($scope.allowThrowCube == false) {
            return;
        }
        $scope.number = getRandomSpan();
        $scope.thisImage = $scope.images[$scope.number];
        $scope.showImage = false;
        $scope.showstage = true;
        $timeout(myFunction, 2000);
        $scope.allowDrop = true;
        $scope.allowThrowCube = false;
    };


    function myFunction() {
        $scope.showstage = false;
        $scope.showImage = true;
    }
    $scope.Getsquere = function () {
        var x = $scope.squers.id
        var q = $scope.squers.image
        var y = $scope.squers.type

    }
    $scope.counter = 0;
    $scope.GetSquaresList = function () {
        SweetDay.GetSquaresList()
        .then(function mySuccess(response) {
            //SweetDay.NotExisting($scope.User.phone)
            if (response.status == 200) {
                $scope.squers = response.data;
            }
            else {

            }
        }, function myError(response) {
            return response.statusText;
        });
    }

    $scope.Save = function () {
        //  $scope.Save = $scope.User
        var userVM = {
            ID: $scope.User.id,
            Glucose: $scope.User.glucose,
            IndexUser: $scope.User.indexUser,
            DoctorVisitNum: $scope.User.doctorVisitNum,
            JunkFoodNum: $scope.User.junkFoodNum,
            Player: $scope.User.player,
            InsulinFull: $scope.User.insulinFull,
            InsulinEmpty: $scope.User.insulinEmpty,
            Dot: $scope.User.dot
        };
        //JSON.stringify(userVM)
        //      SweetDay.Save($scope.User.id,$scope.User.glucose,$scope.User.indexUser,$scope.User.doctorVisitNum, $scope.User.junkFoodNum, $scope.User.player, $scope.User.insulinFull, $scope.User.InsulinEmpty, $scope.User.dot ) //משתנה עם הערכים לשמירה בלבד
        SweetDay.Save(JSON.stringify(userVM))
            .then(function mySuccess(response) {
                if (response.data == false) {
                    console.log("Save in ctrl")
                    //alert('לא היו שינויים');
                    //$scope.template = 'LoginPhons';
                    $scope.template = '/Home/Index';
                }
                else {
                    //$scope.User.insulinFull = 8;
                    //$scope.User.insulinEmpty = 0;
                    $scope.template = '/Login/LoginMain';
                }
            }, function myError(response) {
                return response.statusText;
            });

    }



    $scope.GetSquaresList();
    var hiSugar;
    var lowSugar;
    var levelSugar;
    $scope.randomSugar = function () {
        lowSugar = Math.floor((Math.random() * 50) + 30);
        hiSugar = Math.floor((Math.random() * 380) + 120);
        hiSugar = parseInt(hiSugar / 10);
        hiSugar = hiSugar * 10;
        lowSugar = parseInt(lowSugar / 10);
        lowSugar = lowSugar * 10;
        var choose = Math.floor((Math.random() * 2) + 1);
        if (choose == 1) {
            levelSugar = hiSugar;
            $scope.showHiSugar = true;
            $scope.showLowSugar = false;
            $scope.User.glucose = hiSugar;
        }
        else {
            levelSugar = lowSugar;
            $scope.showLowSugar = true;
            $scope.showHiSugar = false;
            $scope.User.glucose = lowSugar;
        }
        $scope.showModalSugar = true; // view ramat Sugar
    }



    //$scope.activity = { title: "", glucoseDown: "" }
    //$scope.GetActivity = function () {
    //    SweetDay.GetActivity()
    //    .then(function mySuccess(response) {
    //        //SweetDay.NotExisting($scope.User.phone)
    //        if (response.statusText == "OK") {
    //            $scope.activity.title = response.data.Title;
    //            $scope.activity.glucoseDown = response.data.GlucoseDown;
    //        }
    //        else {
    //            //var x = $scope.User.phone;
    //            //window.location = "http://" + window.location.host + "/Login/NewLogin"
    //        }
    //    }, function myError(response) {
    //        return response.statusText;
    //    });;
    //}

    $scope.handleDragStart = function (e) {
        //this.style.opacity = '0.4';
        e.dataTransfer.setData('text/plain', "solider");
    };

    $scope.handleDragEnd = function (e) {
        //this.style.opacity = '1.0';
        //var oldSquare = document.getElementById($scope.currentIndex);
        //document.getElementById(oldSquare.id).innerHTML = "";

        //oldSquare.removeChild(oldSquare.id);
        //var el = document.getElementById('id');
        //el.parentNode.removeChild(el);
    };

    $scope.allowDrop = false;
    $scope.handleDrop = function (e, squere) {
        e.preventDefault();

        if ($scope.User.indexUser > squere.IndexInArrey || squere.IndexInArrey > $scope.User.indexUser + $scope.number || $scope.allowDrop == false) {

            return;
        }
        if ($scope.currentSqure.SquareType == 7)
            $scope.showSurprise = false;
        else if ($scope.showInsulin == true) {
            $scope.showInsulin = false;
            $scope.showPantryInsulin = true;
        }

        else if ($scope.showPantry == true) {
            $scope.showPantry = false;
            $scope.showPantryInsulin = true;
        }

        //var a = e.target;
        e.target.appendChild(document.getElementById("solider"));

        if (squere.IndexInArrey == ($scope.User.indexUser + $scope.number)) {
            $scope.User.indexUser = squere.IndexInArrey;
            $scope.currentSqure = squere;
            $scope.allowDrop = false;
            $scope.showPantryInsulin = false;
            if ($scope.currentSqure.SquareType == 1) {
                $scope.showFood = true;// view Food

            }
            else if ($scope.currentSqure.SquareType == 2) {

                $scope.randomSugar();//
            }

            else if ($scope.currentSqure.SquareType == 4) {
                $scope.showFeelings = true; // view Feelings

            }

                //if ($scope.currentSqure.SquareType == 5) {
                //    $scope.showInsulin = true; // view Insulin
                //}

            else if ($scope.currentSqure.SquareType == 6) {
                $scope.Task();
                $scope.showModalTask = true; // view Task
            }

            else if ($scope.currentSqure.SquareType == 7) {
                $scope.GetSuprise();
                // view Surprise

            }

            if ($scope.currentSqure.IndexInArrey == 43) {
                //$scope.template = '../Home/Win';
                //$scope.User.glucose = 100;
                $scope.winGame();
            }
            //$scope.allowThrowCube = true;
        }

    };

    $scope.handleDragOver = function (e) {
        e.preventDefault(); // Necessary. Allows us to drop.

    };

    $scope.winGame = function () {
        $scope.Init();
    }

    $scope.Init = function () {
        //$scope.User.glucose = 100;
        //$scope.User.indexUser = 0;
        ////$scope.User.insulin = 0;
        //$scope.User.increaseGlucose = 0;
        //$scope.User.decreaseGlucose = 0;
        //$scope.User.doctorVisitNum = 0;
        //$scope.User.carbohydrate = 0;
        //$scope.User.junkFoodNum = 0;
        //$scope.User.insulinFull = 8;
        //$scope.User.insulinEmpty = 0;
        //$scope.User.dot = 0;

        var userInit = {
            ID: $scope.User.id,
            Glucose: 100,
            IndexUser: 0,
            DoctorVisitNum: 0,
            JunkFoodNum: 0,
            InsulinFull: 8,
            InsulinEmpty: 0,
            Dot: 0
        };
        SweetDay.Init(JSON.stringify(userInit))
              .then(function mySuccess(response) {
                  if (response.data == false) {
                      console.log("Save in ctrl")
                      //alert('לא היו שינויים');
                      //$scope.template = 'LoginPhons';
                      $scope.template = '/Home/Index';
                  }
                  else {
                      $scope.template = '/Home/Win';
                      //$scope.User.glucose = 100;
                  }
              }, function myError(response) {
                  return response.statusText;
              });
    }

    //$scope.list = [{ title: "aaa", glucoseDown: "40" }, { title: "bbb", glucoseDown: "50" }, { title: "ccc", glucoseDown: "60" }];
    //$scope.list2 = { title: "ddd", glucoseDown: "40" };
    //$scope.list1 = { title: "aaa", glucoseDown: "40" };

    $scope.surprise = { title: "", type_: "", amount: "" };
    $scope.GetSuprise = function () {
        $scope.showSurprise = true;
        SweetDay.GetSuprise()
        .then(function mySuccess(response) {
            $scope.showSurprise = true;
            if (response.statusText == "OK") {
                $scope.surprise.title = response.data.Title;
                $scope.surprise.amount = response.data.Amount;
                $scope.surprise.type_ = response.data.Type_;
                calc($scope.surprise.amount, $scope.surprise.type_);
            }
            else {
                console.login();
            }
        }, function myError(response) {
            return response.statusText;

        });
    }

    function calc(amount, type) {

        if (type == 1) {
            $scope.number = amount;
            $scope.allowDrop = true;
        }
        else if (type == 2)
            $scope.User.insulinFull += amount;
        else
            $scope.User.dot += amount;

    };
    $scope.SupriseExit = function () {
        $scope.Surprise = false;
    }
    //$scope.models = {
    //    selected: null,
    //    lists: { "A": [], "B": [] }
    //};

    //// Generate initial model
    //for (var i = 1; i <= 3; ++i) {
    //    $scope.models.lists.A.push({ label: "Item A" + i });
    //    $scope.models.lists.B.push({ label: "Item B" + i });
    //}

    //// Model to JSON for demo purpose
    //$scope.$watch('models', function (model) {
    //    $scope.modelAsJson = angular.toJson(model, true);
    //}, true);

    //$scope.new_game = function () {
    //    $scope.template = '../Home/Index';
    //    $scope.showPantryInsulin = true;
    //    $scope.allowThrowCube = true;
    //    $scope.User.indexUser = 0;
    //    $scope.User.Glucose = 100;
    //    $scope.User.InsulinFull = 8;
    //    $scope.User.InsulinEmpty = 0;
    //    $scope.User.dot = 0;
    //}
    $scope.finish = function () {
        $scope.template = '/Login/Main';
    }
});
