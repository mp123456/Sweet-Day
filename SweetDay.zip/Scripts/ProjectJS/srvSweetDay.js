﻿myModule.factory("SweetDay", function ($http) {
    var service = {};
    var urlBase = "/Home/";


    service.IsExisting = function (phone) {
        return $http({
            method: "GET",
            url: "/Login/IsExisting",
            params: { phone: phone }
        })
    }

    service.SaveLogin = function (user) {
        return $http({
            method: "GET",
            url: "/Login/SaveLogin",
            params: {
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                dateOfBirth: user.dateOfBirth,
                insulin: user.insulin,
                Carbohydrate: user.carbohydrate,
                email: user.email,
                sex: user.sex,
                player: user.player
            }
            //params: "{'" + user.firstName + "','" + user.lastName + "'}"
        })
    }
    service.Save = function (user) {
        return $http({
            method: "post",
            url: urlBase+"Save",
            data: {
                user: user
                //indexUser: User.indexUser,
                //player: User.player,
                //glucose: User.glucose,
                //increaseGlucose: User.increaseGlucose,
                //decreaseGlucose: User.decreaseGlucose,
                //insulin: user.insulin
            }
        })
    }

    service.Init = function (user) {
        return $http({
            method: "post",
            url: urlBase + "Init",
            data: {
                user: user
            }
        })
    }


    //service.SaveTheGame = function (user) {
    //    return $http({
    //        method: "GET",
    //        url: "/Login/SaveTheGame",
    //        params: {
    //            //int , String player, int glucose, int increaseGlucose, int decreaseGlucose, int insulin

    //            IndexUser: user.IndexUser,
    //            player: user.Player,
    //            glucose: user.glucose,
    //            increaseGlucose: user.increaseGlucose,
    //            decreaseGlucose: user.decreaseGlucose,
    //            insulin:user.insulin
                
    //        }
          
    //    })
    //}
    //CONNECTION OF THE BOARD TO THE DB 
    service.GetSquaresList = function () {
        return $http({
            method: "GET",
            url: "/Home/GetSquaresList"
        })
    }



    //service.NotExisting = function (phone) {
    //    return $http({
    //        method: "GET",
    //        url: "/Login/IsExisting",
    //        params: { phone: phone }
    //    })
    //}
    service.GetSuprise=function()
    {
        return $http({
            method: "GET",
            url: urlBase + "GetSuprise",
            params:{}
        })
    }
    service.GetActivity = function () {
        return $http({
            method: "GET",
            url: urlBase + "GetActivity",
            params: {}
        })
    }
    service.Task = function () {
        return $http({
            method: "GET",
            url: urlBase + "Task",
            params: {}
        })
    }
    service.SaveChangeRatio = function (id,insulin, Carbohydrate) {
        return $http({
            method: "POST",
            url: urlBase + "SaveChangeRatio",
            data: {id:id, insulin:insulin, Carbohydrate:Carbohydrate }
        })
    }



    return service;
});

